#!/bin/bash
SERVICE_NAME="Share2box DRM Service"
PATH_TO_JAR=/opt/share2box-drm/share2box-drm.jar
JAR_DIR=/opt/share2box-drm
PID_PATH_NAME=/tmp/share2box-drm-pid
MY_IP="$(dig +short myip.opendns.com @resolver1.opendns.com)"
JAVA_OPTS="--add-exports java.base/jdk.internal.misc=ALL-UNNAMED -Dio.netty.tryReflectionSetAccessible=true -server"
case $1 in
    start)
        echo "Starting $SERVICE_NAME ..."
                    if [ ! -f $PID_PATH_NAME ]; then
                        cd $JAR_DIR
                        nohup java $JAVA_OPTS -jar share2box-drm.jar &
                        echo $! > $PID_PATH_NAME-$port
                        echo "$SERVICE_NAME started on port $port ..."
                        sleep 2
                    else
                        echo "$SERVICE_NAME is already running ..."
                    fi
    ;;
    stop)

                if [ -f $PID_PATH_NAME ]; then
                    PID=$(cat $PID_PATH_NAME);
                    echo "$SERVICE_NAME stoping ..."
                    kill $PID;
                    echo "$SERVICE_NAME stopped ..."
                    rm $PID_PATH_NAME
                else
                    echo "$SERVICE_NAME is not running ..."
                fi

    ;;
    restart)
        if [ -f $PID_PATH_NAME ]; then
            PID=$(cat $PID_PATH_NAME);
            echo "$SERVICE_NAME stopping ...";
            kill $PID;
            echo "$SERVICE_NAME stopped ...";
            rm $PID_PATH_NAME
            echo "$SERVICE_NAME starting ..."
            cd $JAR_DIR
            nohup java $JAVA_OPTS -jar share2box-drm.jar &
                        echo $! > $PID_PATH_NAME
            echo "$SERVICE_NAME started ..."
        else
            echo "$SERVICE_NAME is not running ..."
        fi
    ;;
esac

