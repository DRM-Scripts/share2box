<?php
if(isset($_POST['showChannelInfo'])){

    $channel_info = shell_exec('curl -g -X POST -H "Content-Type: application/json" -d \'{"query":"query{channelInfo(id: '.$_POST['id'].'){video { label }}}"}\' http://'.$_SERVER['SERVER_ADDR'].':8989/api/graphql');
    $channel_info = json_decode($channel_info, true);

    class MyDB extends SQLite3 {
        function __construct() {
            $this->open('../channels_new.db');
        }
    }
    
    $db = new MyDB();   

    $channel = $db->query('SELECT * FROM Channels WHERE id = "'.$_POST['id'].'"');
    $channel_row = $channel->fetchArray(SQLITE3_ASSOC);

    echo '<strong>Channel:</strong> ' .$channel_row['name'].'<br /><br />';
    if(array_key_exists('errors', $channel_info)){
        echo "Channel information can not fetch.";
    } else {
        echo '<div class="alert alert-info">Dont set the index to get highest resolution</strong></div>';

        foreach($channel_info['data']['channelInfo']['video'] as $info_key => $info_value){
            echo '<ul>';
                echo '<li>Index: '.$info_key.' - Resolution: '.$info_value['label'].'</li>';
            echo '</ul>';
        }

        echo '<form method="post">';
            echo '<div class="input-group mb-3">';
                echo '<input type="text" class="form-control" name="videoIndex" placeholder="Video Index" value="'.$channel_row['vIndex'].'" />';
                echo '<button class="btn btn-success" type="submit" name="saveIndex" id="button-addon2">Save Index</button>';
                echo '<input type="hidden" name="chId" value="'.$_POST['id'].'" />';
            echo '</div>';
        echo '</form>';
    }
}

if(isset($_POST['editChannel'])){
    class MyDB extends SQLite3 {
        function __construct() {
            $this->open('../channels_new.db');
        }
    }
    
    $db = new MyDB();   

    $channel = $db->query('SELECT Channels.id, Channels.name, Channels.provider, Channels.url, Keys.kid, Keys.key FROM Channels LEFT JOIN Keys ON Channels.id = Keys.channelId WHERE Channels.id = "'.$_POST['id'].'"');
    $channel_row = $channel->fetchArray(SQLITE3_ASSOC);

    echo '<strong>Channel:</strong> ' .$channel_row['name'].'<br /><br />';

    echo '<form method="post">';
        echo '<div class="input-group mb-3">';
            echo '<input type="index" class="form-control" name="channelName" id="inputGroup-sizing-default" placeholder="Channel Name" value="'.$channel_row['name'].'">';
            echo '<select class="select" name="channelProvider" id="inputGroupSelect01">';
            echo '<option>Choose Provider</option>';
            $provider = $db->query('SELECT * FROM `Providers`');
            while ($providers = $provider->fetchArray(SQLITE3_ASSOC)) {
                echo '<option value="'.$providers['name'].'" '.($providers['name'] == $channel_row['provider'] ? 'selected' : '').'>'.$providers['name'].'</option>';
            }
            echo '</select>';
        echo '</div>';
        echo '<div class="input-group mb-3">';
            echo '<input type="index" class="form-control" name="channelURL" placeholder="Url" value="'.$channel_row['url'].'">';
        echo '</div>';
        echo '<input type="hidden" name="channelId" value="'.$_POST['id'].'" />';
        echo '<button type="submit" name="save-channel" class="btn btn-primary">Save Channel</button>';
    echo '</form>';
}

if(isset($_POST['showKeys'])){
    class MyDB extends SQLite3 {
        function __construct() {
            $this->open('../channels_new.db');
        }
    }
    
    $db = new MyDB();   

    $keys = $db->query('SELECT Channels.id, Channels.name, Channels.provider, Channels.url, Keys.kid, Keys.key FROM Keys LEFT JOIN Channels ON Keys.channelId = Channels.id WHERE Channels.id = "'.$_POST['id'].'"');

    echo '<form method="post" class="form-keys">';
        echo '<div class="sources">';

                $i = 0;
                while($keys_row = $keys->fetchArray(SQLITE3_ASSOC)){
                    if($keys_row){
                        echo '<div class="keys-block" data-id="'.$i.'">';
                            echo '<div class="input-group mb-3">';
                                echo '<input type="index" class="form-control" name="channelKid[]" placeholder="KID" value="'.$keys_row['kid'].'">';
                                echo '<input type="index" class="form-control" name="channelKey[]" placeholder="KEY" value="'.$keys_row['key'].'">';
                                echo '<button class="btn btn-danger" onclick="deleteKey(this); return false">Delete</button>';
                                echo '<button class="btn btn-primary" onclick="addKey(); return false">Add</button>';
                            echo '</div>';

                        echo '</div>';
                    }
                    $i++;
                }

                echo '<div class="keys-block" data-id="0">';
                    echo '<div class="input-group mb-3">';
                        echo '<input type="index" class="form-control" name="channelKid[]" placeholder="KID">';
                        echo '<input type="index" class="form-control" name="channelKey[]" placeholder="KEY">';
                        echo '<button class="btn btn-danger" onclick="deleteKey(this); return false">Delete</button>';
                        echo '<button class="btn btn-primary" onclick="addKey(); return false">Add</button>';
                    echo '</div>';
                echo '</div>';
          
   
        echo '</div>';
        echo '<input type="hidden" name="channelId" value="'.$_POST['id'].'" />';
        echo '<button type="submit" name="save-key" class="btn btn-primary">Save Keys</button>';
    echo '</form>';

}

?>


<script>
function addKey(){
    var data_id = parseInt($(".keys-block:last").attr("data-id"));

    var newDataID = data_id + 1;
    $(".keys-block:first").clone().attr("data-id", newDataID).appendTo(".sources");
    $("[data-id="+newDataID+"]").find('input').val("");
}

function deleteKey(id){
    event.preventDefault();
    if ($(".sources").length > 1) {
        $(id).parent().parent().remove();
    }

    return false;
}
</script>